require 'puppet/util/feature'

Puppet.features.add(:foreman_api, :libs => %{foreman_api})
