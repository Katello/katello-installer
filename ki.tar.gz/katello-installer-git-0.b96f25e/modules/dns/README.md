DNS
===

A puppet module to setup bind for The Foreman

## Dependencies

* Native-type Concat module (https://github.com/onyxpoint/pupmod-concat)

ToDo
----
OSes other than Debian

Credits
-------

Based on zleslie-dns, with a lot of the guts ripped out. Thanks
to zleslie for the original work

