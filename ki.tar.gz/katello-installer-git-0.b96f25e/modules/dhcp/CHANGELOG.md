# Changelog

## 1.3.1
* Change Debian package name to prevent reinstallation on each run
* Fix puppet-lint issues
