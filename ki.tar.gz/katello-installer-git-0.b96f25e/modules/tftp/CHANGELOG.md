# Changelog

## 1.4.0
* Add Amazon Linux support
* Puppet 2.6 support deprecated
* Cleanup of manifest style
* Add tests
